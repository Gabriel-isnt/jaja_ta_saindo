public class Cardapio{
        
        private DiaSemana dia;

        public Cardapio(DiaSemana dia){
                this.dia = dia;
        }

        public void mostraCardapio(){
                switch (dia){
                        case DOMINGO:
                                System.out.println("mamae");
                                break;
                        
                        case SEGUNDA:
                                System.out.println("papai");
                                break;
                }
        }


}


