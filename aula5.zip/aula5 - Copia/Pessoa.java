abstract class Pessoa{
        private int id;
        private int telefone;
        private String nome;
        private String endereco;


        public Pessoa(int id, int telefone, String nome, String endereco){
                this.id = id;
                this.telefone = telefone;
                this.nome = nome;
                this.endereco = endereco;
        }


        public int getId(){ return id; }
        public int getTelefone(){ return telefone; }
        public String getNome(){ return nome; }
        public String getEndereco() { return endereco; }

        public void setId(int id){ this.id = id; }
        public void setTelefone(int telefone){ this.telefone = telefone; }
        public void setNome(String nome){ this.nome = nome; }
        public void setEndereco(String endereco){ this.endereco = endereco; }


}


