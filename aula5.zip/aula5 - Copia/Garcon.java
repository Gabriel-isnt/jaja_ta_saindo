class Garcon extends Pessoa{

        public Garcon(int id, int telefone, String nome, String endereco){
                super(id, telefone, nome, endereco);
        }

        public void ofereceCardapio(Cardapio cardapio){
                
        }
}